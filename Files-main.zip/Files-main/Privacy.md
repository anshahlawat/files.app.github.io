**Privacy Policy**

*Personal Information Collection* 
Files does not collect, store, share or publish any personal information.

*Non-personal Information Collection*

We use App Center to keep track of app usage, find bugs, and fix crashes. All information sent to App Center is anonymous and free of any user or contextual data.
