﻿using Files.Filesystem;

namespace Files.ViewModels.Previews
{
    public class BasicPreviewViewModel : BasePreviewModel
    {
        public BasicPreviewViewModel(ListedItem item) : base(item)
        {
        }
    }
}