﻿using Windows.UI.Xaml.Controls;

namespace Files.SettingsPages
{
    public sealed partial class Sidebar : Page
    {
        public Sidebar()
        {
            InitializeComponent();
        }
    }
}