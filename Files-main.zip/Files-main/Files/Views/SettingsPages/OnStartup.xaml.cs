﻿using Windows.UI.Xaml.Controls;

namespace Files.SettingsPages
{
    public sealed partial class OnStartup : Page
    {
        public OnStartup()
        {
            InitializeComponent();
        }
    }
}