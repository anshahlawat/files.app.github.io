﻿using Windows.UI.Xaml.Controls;

namespace Files.SettingsPages
{
    public sealed partial class Experimental : Page
    {
        public Experimental()
        {
            InitializeComponent();
        }
    }
}