﻿using Windows.UI.Xaml.Controls;

namespace Files.SettingsPages
{
    public sealed partial class Preferences : Page
    {
        public Preferences()
        {
            InitializeComponent();
        }
    }
}