﻿using Windows.UI.Xaml.Controls;

namespace Files.Views
{
    public class ColumnParam
    {
        public int Column { get; set; }
        public string Path { get; set; }
        public ListView ListView { get; set; }
    }
}