﻿namespace Files.Enums
{
    public enum TimeStyle
    {
        Application = 0,
        System = 1
    }
}