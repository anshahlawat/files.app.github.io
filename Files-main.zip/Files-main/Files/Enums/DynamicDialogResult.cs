﻿namespace Files.Enums
{
    public enum DynamicDialogResult
    {
        Primary = 1,
        Secondary = 2,
        Cancel = 4,
    }
}