﻿namespace Files.Enums
{
    public enum WallpaperType
    {
        Desktop,
        LockScreen
    }
}