﻿namespace Files.Enums
{
    public enum FilesystemOperationType
    {
        Copy = 0,
        Move = 1,
        Delete = 2
    }
}