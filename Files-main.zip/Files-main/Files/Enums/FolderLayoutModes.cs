﻿namespace Files.Enums
{
    public enum FolderLayoutModes
    {
        DetailsView = 1,
        TilesView = 2,
        ColumnView = 3,
        GridView = 4,
    }
}