﻿namespace Files.Enums
{
    public enum SidebarOpacity
    {
        Opaque = 0,
        IsAcrylicDisabled = 1
    }
}