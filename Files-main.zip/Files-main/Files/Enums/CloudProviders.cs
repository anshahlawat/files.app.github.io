﻿namespace Files.Enums
{
    public enum CloudProviders
    {
        OneDrive,
        OneDriveCommercial,
        Mega,
        GoogleDrive,
        DropBox,
        AppleCloud,
        AmazonDrive,
        Box
    }
}