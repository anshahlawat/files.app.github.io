﻿namespace Files.Enums
{
    public enum FormFactorMode
    {
        Regular = 0,
        //TouchEnhancedRegular = 1,
        //Tablet = 2,
        //Cloud = 3,
        //Classic = 4
    }
}