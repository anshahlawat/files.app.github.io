﻿namespace Files.CommandLine
{
    internal class ParsedCommand
    {
        public ParsedCommandType Type { get; set; }

        public string Payload { get; set; }
    }
}