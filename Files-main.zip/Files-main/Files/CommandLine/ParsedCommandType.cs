﻿namespace Files.CommandLine
{
    internal enum ParsedCommandType
    {
        Unknown,
        OpenDirectory,
        OpenPath,
        ExplorerShellCommand
    }
}