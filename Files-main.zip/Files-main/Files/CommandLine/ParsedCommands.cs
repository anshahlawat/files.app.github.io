﻿using System.Collections.Generic;

namespace Files.CommandLine
{
    internal class ParsedCommands : List<ParsedCommand>
    {
    }
}