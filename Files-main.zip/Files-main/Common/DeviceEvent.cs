﻿namespace Files.Common
{
    public enum DeviceEvent
    {
        Added,
        Removed,
        Inserted,
        Ejected
    }
}